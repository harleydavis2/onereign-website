# OneReign Website — TODO V3
> ⚠️ This replaces all previous TODO files. Use this one only.  
> Status: `[ ]` pending · `[~]` in progress · `[x]` done

---

## Phase 1 — Foundation
- [ ] Set up project folder structure (index.html, style.css, main.js, three-*.js files, assets/)
- [ ] Add logo PNG to assets folder
- [ ] Load fonts via CDN (Clash Display + Satoshi via Fontshare, JetBrains Mono via Google Fonts)
- [ ] Define all CSS custom properties in `:root` (colors, spacing, radius, transitions)
- [ ] Add global base styles (reset, body, scrollbar, selection color)
- [ ] Add full-page CSS noise texture via inline SVG `feTurbulence` filter at 2% opacity

## Phase 2 — Background System (Geometric Patterns)
- [ ] **Pattern A — Emergence Grid**: SVG dot grid (1px dots, 32px spacing, 6% white opacity) — used in Hero + Footer
- [ ] **Pattern B — Hexagonal Mesh**: SVG repeating hex outline grid (0.5px stroke, blue 5% opacity) — used in Services + Portfolio
- [ ] **Pattern C — Diagonal Noise Lines**: CSS repeating-linear-gradient 45°, 3% white, 8px repeat — used in About
- [ ] **Pattern D — Radial Burst**: SVG 24 radial lines from center-right, purple 8% opacity — used in Contact
- [ ] **Pattern E — Resolution Pattern**: SVG concentric hexagons 800px centered, 4% white opacity — used in Team
- [ ] Apply correct pattern to each section as absolute background layer

## Phase 3 — Three.js 3D Elements
- [ ] **Element 1 — Hero Particle Field**: WebGL canvas, drifting connected nodes (blue), mouse pull interaction, fades on scroll
- [ ] **Element 2 — Hero Hex Geometry**: IcosahedronGeometry wireframe, slow Y-axis rotation (0.001 rad/frame), mouse drag rotation, blue point light, right side of hero
- [ ] **Element 3 — Service Card Icons**: 5 small 80px canvases per service card (TorusKnot, Icosahedron, Octahedron, Box, Torus), blue metallic material, pause on hover
- [ ] **Element 4 — About Mesh Background**: Undulating sine-wave grid plane, very low opacity wireframe, calm ocean motion

## Phase 4 — Navigation
- [ ] Fixed nav: glassmorphism background (`rgba(10,10,10,0.8)` + `backdrop-filter: blur(20px)`)
- [ ] Left: static logo (fade-in on load, NO other animation ever)
- [ ] Right: nav links + "Get in Touch" CTA button
- [ ] Scroll behavior: border becomes more visible past 80px scroll
- [ ] Mobile: hamburger icon → full-screen overlay menu with staggered link reveals

## Phase 5 — Hero Section
- [ ] Full viewport height layout (left 55% text, right 45% Three.js canvas)
- [ ] Caption label: `WHERE POSSIBILITY BECOMES INEVITABLE`
- [ ] H1 two lines: `Deep research.` / `Engineered reality.`
- [ ] Body copy + two CTA buttons (solid blue + ghost outline)
- [ ] Trust stats bar: `12+ Projects · 6 Domains · 100% Client Retention`
- [ ] Staggered entrance animation sequence (10 steps, 80ms apart)
- [ ] Background: Particle Field (Element 1) + Emergence Grid (Pattern A) layered

## Phase 6 — Marquee Trust Bar
- [ ] Full-width scrolling marquee between Hero and About
- [ ] Text: `RESEARCH · ENGINEERING · DESIGN · PRODUCTS · PLATFORMS · DEEP WORK · EMERGENT SYSTEMS · INEVITABLE OUTCOMES ·`
- [ ] `animation: marquee 30s linear infinite`, duplicated for seamless loop
- [ ] Background `#111111`, text 40% white opacity, Satoshi caption style

## Phase 7 — About Section
- [ ] Background: About Mesh (Element 4) + Diagonal Noise (Pattern C)
- [ ] Left: large H2 pull quote
- [ ] Right: Vision / Mission / Philosophy blocks with colored left-border accents
- [ ] Bottom: horizontal divider with five brand pillars in spaced caps

## Phase 8 — Services Section
- [ ] Caption + H2
- [ ] 5 service cards with Three.js canvas icons (Element 3)
- [ ] Card styles: dark surface, subtle border, hover → blue border
- [ ] Background: Hexagonal Mesh (Pattern B)
- [ ] Horizontal scroll on mobile

## Phase 9 — Portfolio / Work Section
- [ ] Caption + H2
- [ ] Filter pills: All · Design · Engineering · Research · Product
- [ ] 3-column grid → 2 tablet → 1 mobile
- [ ] 6 realistic placeholder project cards
- [ ] Card anatomy: thumbnail → badge → title → description → tool tags → link
- [ ] Hover: translateY(-6px) + blue top border glow
- [ ] Filter JS: show/hide cards by category
- [ ] Background: Hexagonal Mesh (Pattern B)

## Phase 10 — Team Section
- [ ] Caption + H2
- [ ] 3–4 profile cards with initials avatar (gradient background), name, role, bio, social icons
- [ ] Card hover: scale(1.02) + border accent
- [ ] Background: Resolution Pattern (Pattern E)

## Phase 11 — Contact Section
- [ ] Caption + H2
- [ ] Left: contact form (Name, Email, Project Type dropdown, Message, Send)
- [ ] Right: email, response time, social links
- [ ] Form input styles: dark surface, focus → blue border glow
- [ ] Background: Radial Burst (Pattern D) + bottom-right photonic glow

## Phase 12 — Footer
- [ ] Logo (static) + tagline
- [ ] Three link columns: Company / Work / Connect
- [ ] Bottom bar: copyright + five brand pillars
- [ ] Background: Emergence Grid (Pattern A)

## Phase 13 — Scroll Reveals & Micro-interactions
- [ ] IntersectionObserver on all sections (threshold 0.15)
- [ ] Entry animation: opacity 0 + translateY(30px) → opacity 1 + translateY(0), 600ms ease-out
- [ ] Card stagger: each card delays by `index * 80ms`
- [ ] Nav link hover: underline slides in via CSS `::after`
- [ ] Button hover: glow + lighten

## Phase 14 — Responsive
- [ ] Mobile layout (< 768px): single column, hamburger nav, hidden 3D hex
- [ ] Tablet (768–1280px): 2-column grid, adjusted font sizes
- [ ] Test all sections at 375px, 768px, 1280px, 1920px

## Phase 15 — Polish & QA
- [ ] Check no logo rotation/animation exists anywhere in code
- [ ] Verify all 5 background patterns are applied to correct sections
- [ ] Verify all 4 Three.js elements initialize without errors
- [ ] Check font loading (Clash Display rendering correctly)
- [ ] Accessibility: alt text, ARIA labels, keyboard nav
- [ ] Performance: lazy load images, check canvas frame rate
- [ ] Cross-browser: Chrome, Firefox, Safari

## Phase 16 — Deployment
- [ ] Initialize GitHub repo, push all files
- [ ] Connect to Vercel, configure build settings
- [ ] Add custom domain
- [ ] Configure OG meta tags (title, description, image)
- [ ] Final production deploy
- [ ] Log deploy URL in BUILD_LOG.md

---

_Last updated: 2026-06-05 — V3_
